number_1 = 20
number_2 = 12

sum = number_1 + number_2
print("The sum of {0} and {1} is {2}". format (number_1, number_2, sum))
